package com.example.delivereat.entities;

public class Localidad {
}
